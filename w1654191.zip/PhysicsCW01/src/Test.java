import java.util.Scanner;

public class Test {
	static Scanner input = new Scanner(System.in);
	public static void main(String []args){
		mainMenu();
		
	}
	public static void mainMenu(){
		System.out.println("Press [1] to Do 2D vector calculations");
		System.out.println("Press [2] to Do 3D vector calculations");
		System.out.println("Press [3] to Do Advance calculations");
		String user = input.next();
		switch(user){
		case "1" : Vector2DCalculation();
		break;
		case "2" : vector3DCalculation();
		break;
		case "3" : advanvceQuestion();
		break;
		}
	}
	
	public static void Vector2DCalculation(){
		System.out.println("Press [1] to 2D vector Additions.");
		System.out.println("Press [2] to 2D vector Subtraction.");
		System.out.println("Press [3] to 2D vector Dot Product.");
		System.out.println("Press [4] to 2D vector Unit Vector.");
		System.out.println("Press [5] to 2D vector Magnitute.");
		System.out.println("Press [6] to 2D vector Multiplication.");
		System.out.println("Press [7] to 2D vector Rotaion.");
		System.out.println("Press [8] to 2D vector Velocity vector.");
		System.out.println("Press [9] to 2D vector Scalar Multiplication");
		String user = input.next();
		switch(user){
		case "1" : add2DVector();
		break;
		case "2" : sub2DVector();
		break;
		case "3" : DotProduct2D();
		break;
		case "4" : unit2DVector();
		break;
		case "5" : magnitute2D();
		break;
		case "6" : vectorMultiple();
		break;
		case "7" : vector2DRotation();
		break;
		case "8" : velocityVector();
		break;
		case "9" : scalarMultiple2D();
		break;
		}
	}
	
	public static void vector3DCalculation(){
		System.out.println("Press [1] to 3D vector Additions.");
		System.out.println("Press [2] to 3D vector Subtraction.");
		System.out.println("Press [3] to 3D vector Dot Product.");
		System.out.println("Press [4] to 3D vector Unit Vector.");
		System.out.println("Press [5] to 3D vector Magnitute.");
		System.out.println("Press [6] to 3D vector Multiplication.");
		System.out.println("Press [7] to 3D vector Scalar Multiplication");
		String user = input.next();
		switch(user){
		case "1" : add3DVector();
		break;
		case "2" : sub3DVector();
		break;
		case "3" : dotProduct3DVector();
		break;
		case "4" : unitVector3DVector();
		break;
		case "5" : magnitute3DVector();
		break;
		case "6" : multiple3DVector();
		break;
		case "7" : scalarMultiple3DVector();
		break;
		}
	}
	public static void advanvceQuestion(){
		System.out.println("Press [1] to Question A Calculations.");
		System.out.println("Press [2] to Question B Calculations.");
		System.out.println("Press [3] to Question C Calculations.");
		String user = input.next();
		switch(user){
		case "1" : questionA();
		break;
		case "2" : questionB();
		break;
		case "3" : questionC();
		break;
		}
	}
	public static void returnEnd(){
		System.out.println("\n"+ "Press [0] to Go to main menu.");
		System.out.println("Press [e] to Go to End.");
		String user = input.next();
		switch(user){
		case "0" : mainMenu();
		break;
		case "e" : input.close();
		break;
		}
	}
	public static void add2DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		Vector2D vector2 = new Vector2D(x2,y2);
		q1.add2DVector(vector1, vector2);
		System.out.println("The addition of vectors : " + q1.add2DVector(vector1, vector2).getX() + "," + q1.add2DVector(vector1, vector2).getY());
		returnEnd();
	}
	
	public static void sub2DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		Vector2D vector2 = new Vector2D(x2,y2);
		q1.sub2DVector(vector1, vector2);
		System.out.println("The subtraction of vectors : " + q1.sub2DVector(vector1, vector2).getX() + "," + q1.sub2DVector(vector1, vector2).getY());
		returnEnd();
	}
	
	public static void DotProduct2D(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		Vector2D vector2 = new Vector2D(x2,y2);
		q1.dotProduct(vector1, vector2);
		System.out.println("The Dot product of vectors : " + q1.dotProduct(vector1, vector2));
		returnEnd();
	}
	
	public static void unit2DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		Vector2D vector2 = new Vector2D(x2,y2);
		q1.unitVector(vector1, vector2);
		System.out.println("The Unit Vector of vectors : " + q1.unitVector(vector1, vector2));
		returnEnd();
	}
	
	public static void magnitute2D(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		q1.findMagnitute(vector1);
		System.out.println("The Magnitute of vectors : " + q1.findMagnitute(vector1));
		returnEnd();
	}
	
	public static void vectorMultiple(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		Vector2D vector2 = new Vector2D(x2,y2);
		q1.vectorMultiple(vector1, vector2);
		System.out.println("The Unit Vector of vectors : " + q1.vectorMultiple(vector1, vector2).getX() + "," + q1.vectorMultiple(vector1, vector2).getY());
		returnEnd();
	}
	
	public static void vector2DRotation(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter a angle : ");
		double angle = input.nextDouble();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		q1.vectorRotation(vector1, angle);
		System.out.print("The vector rotation is : " + q1.vectorRotation(vector1, angle).getX() + "," + q1.vectorRotation(vector1, angle).getY());
		returnEnd();
	}
	
	public static void velocityVector(){
		System.out.print("Enter a speed : ");
		double speed = input.nextDouble();
		System.out.print("Enter a angle : ");
		double angle = input.nextDouble();
		Vector2DMaths q1 = new Vector2DMaths();
		q1.findVelocityVector(speed, angle);
		System.out.print("The Velocity vector is : " + q1.findVelocityVector(speed, angle).getX() + "," + q1.findVelocityVector(speed, angle).getY());
		returnEnd();
	}
	
	public static void scalarMultiple2D(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter a Scalar : ");
		double scalar = input.nextDouble();
		Vector2DMaths q1 = new Vector2DMaths();
		Vector2D vector1 = new Vector2D(x1,y1);
		q1.scalarMultiple(vector1, scalar);
		System.out.print("The Multiplication of vector is : " + q1.scalarMultiple(vector1, scalar).getX() + "," + q1.scalarMultiple(vector1, scalar).getY());
		returnEnd();
	}
	
//	public static void questionA(){
//		System.out.print("Enter a speed : ");
//		double speed = input.nextDouble();
//		System.out.print("Enter a angle : ");
//		double angle = input.nextDouble();
//		System.out.print("Enter a time : ");
//		double time = input.nextDouble();
//		Vector2DMaths q1 = new Vector2DMaths();
//		q1.questionA(speed, angle, time);
//		System.out.println("" + q1.questionA(speed, angle, time));
//		System.out.print(q1.findVelocityVector(speed, angle).getX() + "," + q1.findVelocityVector(speed, angle).getY());
//	}
	
	// vECTOR_3D
	public static void add3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		System.out.print("Enter Z2 : ");
		float z2 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		Vector3D vector2 = new Vector3D(x2,y2,z2);
		q1.add3DVector(vector1, vector2);
		System.out.println("The addition of vectors : " + q1.add3DVector(vector1, vector2).getX() + "," + q1.add3DVector(vector1, vector2).getY() + "," + q1.add3DVector(vector1, vector2).getZ());
		returnEnd();
	}
	
	public static void sub3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		System.out.print("Enter Z2 : ");
		float z2 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		Vector3D vector2 = new Vector3D(x2,y2,z2);
		q1.sub3DVector(vector1, vector2);
		System.out.println("The subtraction of vectors : " + q1.sub3DVector(vector1, vector2).getX() + "," + q1.sub3DVector(vector1, vector2).getY() + "," + q1.sub3DVector(vector1, vector2).getZ());
		returnEnd();
	}
	
	public static void dotProduct3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		System.out.print("Enter Z2 : ");
		float z2 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		Vector3D vector2 = new Vector3D(x2,y2,z2);
		System.out.println("The Dot product of vectors : " + q1.dotProduct3DVector(vector1, vector2));
		returnEnd();
	}
	
	public static void unitVector3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		System.out.print("Enter Z2 : ");
		float z2 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		Vector3D vector2 = new Vector3D(x2,y2,z2);
		System.out.println("The unitVector of vectors : " + q1.findUnitVector(vector1, vector2));
		returnEnd();
	}
	
	public static void magnitute3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		System.out.println("The magnitute of vectors : " + q1.findMagnitute(vector1));
		returnEnd();
	}
	
	public static void multiple3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter X2 : ");
		float x2 = input.nextFloat();
		System.out.print("Enter Y2 : ");
		float y2 = input.nextFloat();
		System.out.print("Enter Z2 : ");
		float z2 = input.nextFloat();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		Vector3D vector2 = new Vector3D(x2,y2,z2);
		System.out.println("The unitVector of vectors : " + q1.multipleVector(vector1, vector2).getX() + "," + q1.multipleVector(vector1, vector2).getY() + "," + q1.multipleVector(vector1, vector2).getZ());
		returnEnd();
	}
	
	public static void scalarMultiple3DVector(){
		System.out.print("Enter X1 : ");
		float x1 = input.nextFloat();
		System.out.print("Enter Y1 : ");
		float y1 = input.nextFloat();
		System.out.print("Enter Z1 : ");
		float z1 = input.nextFloat();
		System.out.print("Enter Scalar : ");
		double scalar = input.nextDouble();
		Vector3DMaths q1 = new Vector3DMaths();
		Vector3D vector1 = new Vector3D(x1,y1,z1);
		System.out.println("The unitVector of vectors : " + q1.multipleScalarVector(vector1, scalar).getX() + "," + q1.multipleScalarVector(vector1, scalar).getY() + "," + q1.multipleScalarVector(vector1, scalar).getZ());
		returnEnd();
	}
	
	public static void questionA(){
		System.out.print("Enter the velocity : ");
		double velocity = input.nextDouble();
		System.out.print("Enter the angle : ");
		double angle = input.nextDouble();
		Vector3DMaths qA = new Vector3DMaths();
		qA.questionA(velocity, angle);
		returnEnd();
	}
	
	public static void questionB(){
		System.out.print("Enter X: ");
		float x = input.nextFloat();
		System.out.print("Enter Y: ");
		float y = input.nextFloat();
		System.out.print("Enter Z: ");
		float z = input.nextFloat();
		
		System.out.print("Enter time: ");
		double time = input.nextDouble();
		System.out.print("Enter mass: ");
		double mass = input.nextDouble();
		Vector3D vector1 = new Vector3D(x,y,z);
		Vector2DMaths qB = new Vector2DMaths();
		qB.questionB(time, vector1, mass);
		returnEnd();
		
	}
	
	public static void questionC(){
		System.out.print("Enter X: ");
		float x = input.nextFloat();
		System.out.print("Enter Y: ");
		float y = input.nextFloat();
		System.out.print("Enter distance: ");
		double distance = input.nextDouble();
		System.out.print("Enter Mass: ");
		double mass = input.nextDouble();
		System.out.print("Enter force: ");
		double force = input.nextDouble();
		System.out.print("Enter angle: ");
		double angle = input.nextDouble();
		System.out.print("Enter radius: ");
		double radius = input.nextDouble();
		
		Vector2D vector1 = new Vector2D(x,y);
		Vector3DMaths qC = new Vector3DMaths();
		qC.questionC(vector1, distance, mass, force, angle, radius);
		returnEnd();
		
	}
}

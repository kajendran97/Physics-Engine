import java.util.ArrayList;

public class Vector3DMaths {  
	
	/* This method is to find the addition of two 3D vectors and two 3D vector parameters are passed 
	 * to this method and it will return the addition of both vectors as a 3D vector object
	 */
	public static Vector3D add3DVector(Vector3D vector1,Vector3D vector2){
		Vector3D add3DVector = new Vector3D();
		add3DVector.setX(vector1.getX() + vector2.getX());
		add3DVector.setY(vector1.getY() + vector2.getY());
		add3DVector.setZ(vector1.getZ() + vector2.getZ());
		return add3DVector;
	}

	/* This method is to find the subtraction of two 3D vectors and two 3D vector parameters are passed 
	 * to this method and it will return the subtraction of both vectors as a 3D vector object
	 */
	public static Vector3D sub3DVector(Vector3D vector1,Vector3D vector2){
		Vector3D sub3DVector = new Vector3D();
		sub3DVector.setX(vector1.getX() - vector2.getX());
		sub3DVector.setY(vector1.getY() - vector2.getY());
		sub3DVector.setZ(vector1.getZ() - vector2.getZ());
		return sub3DVector;
	}
	
	/* This method is to find the dot product two vectors and two 3D vector parameters are passed 
	 * to this method and it will return the dot product of both vectors as a 3D vector object
	 */
	public static float dotProduct3DVector(Vector3D vector1, Vector3D vector2){
		Vector3D dotProduct = new Vector3D();
		dotProduct.setX(vector1.getX() * vector2.getX());
		dotProduct.setY(vector1.getY() * vector2.getY());
		dotProduct.setZ(vector1.getZ() * vector2.getZ());
		float result = dotProduct.getX() + dotProduct.getY() + dotProduct.getZ();
		return result;
	}

	/* This method is to find unit vector of two vectors and two 3D vector parameters are passed 
	 * to this method and it will return the  unit vector of both vectors as a float variable.
	 */
	public static double findUnitVector(Vector3D vector1, Vector3D vector2){
		Vector3D unitVector = new Vector3D();
		unitVector.setX(vector1.getX() * vector2.getX());
		unitVector.setY(vector1.getY() * vector2.getY());
		unitVector.setZ(vector1.getZ() * vector2.getZ());
		float result = unitVector.getX() + unitVector.getY() + unitVector.getZ();
		
		double x = Math.sqrt((vector1.getX() * vector1.getX()) + (vector1.getY() * vector1.getY()) + (vector1.getZ() * vector1.getZ()));
		double y = Math.sqrt((vector2.getX() * vector2.getX()) + (vector2.getY() * vector2.getY()) + (vector2.getZ() * vector2.getZ()));

		double ans = Math.cos(result / (x*y));
		return ans;
	}
	
	/* This method is to find the magnitute of two vectors and 3D vector parameter is passed 
	 * to this method and it will return the magnitute value of vector as a float variable.
	 */
	public static double findMagnitute(Vector3D vector1){
		double result = Math.sqrt((vector1.getX() * vector1.getX()) + (vector1.getY() * vector1.getY()) + (vector1.getZ() * vector1.getZ()));
		return result;
	}

	/* This method is to find the multiplication of two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the multiplication of both vectors as a 3D vector object.
	 */
	public static Vector3D multipleVector(Vector3D vector1,Vector3D vector2){
		Vector3D multipleVector = new Vector3D();
		multipleVector.setX(vector1.getX() * vector2.getX());
		multipleVector.setY(vector1.getY() * vector2.getY());
		multipleVector.setZ(vector1.getZ() * vector2.getZ());
		return multipleVector;
	}
	
	/* This method is to find the multplication of vectors by scalar and 2D vector parameter , scalar are passed 
	 * to this method and it will return the multiplication of vectors as a 3D vector object.
	 */
	public static Vector3D multipleScalarVector(Vector3D vector1,double scalar){
		Vector3D multipleScalarVector = new Vector3D();
		multipleScalarVector.setX((float)(vector1.getX() * scalar));
		multipleScalarVector.setY((float)(vector1.getY() * scalar));
		multipleScalarVector.setZ((float)(vector1.getZ() * scalar));
		return multipleScalarVector;
	}

	/* This method is to find the initial and final velocaity vector vectors and 3D vector parameter , time are passed 
	 * to this method and it will return the V and U of vectors as a double veariable.
	 */
//	public static double questionB(Vector3D vector1,double time){
//		Vector3D vectorQuestionB = new Vector3D();
//		double angle = Math.toDegrees(Math.asin(((vector1.getX())/(Math.sqrt((vector1.getX() * (vector1.getX() + (vector1.getY() * vector1.getY())+(vector1.getZ() * vector1.getZ()))))))));
//		double u =((9.81) * ((time)/2))/Math.sin(Math.toRadians(angle));
//		double v =((u * (Math.sin(Math.toRadians(angle))))) - (9.81 * time);
//		vectorQuestionB.setX((float) (v * Math.cos(Math.toRadians(angle))));
//		vectorQuestionB.setY((float) (v * Math.sin(Math.toRadians(angle))));
//		vectorQuestionB.setZ(vector1.getZ());
//		System.out.println(vectorQuestionB.getX() + "," + vectorQuestionB.getY() + "," + vectorQuestionB.getZ());
//		return u;
//	}
	public static void questionA(double velocity,double angle){
		
		ArrayList <Float> vector2Dlist = new ArrayList<Float>();   // creating the arraylists to store the position and velocity vector components.
		ArrayList <Float> ComponentXList = new ArrayList<Float>();
		ArrayList <Float> ComponentYList = new ArrayList<Float>();
		
        double time = (velocity * Math.sin(Math.toRadians(angle)) * 2)/9.82; // t = v * (sin(q) * 2)/9.82
        
        double Xcomponent = velocity * Math.cos(Math.toRadians(angle)); // X = v * cos(Q)   calculating the velocity vector
        double Ycomponent = velocity * Math.sin(Math.toRadians(angle)); // Y = v * sin(Q)
        
        double positionX = Xcomponent; // keep tracking of x
        double positionY = Ycomponent; // keep tracking of y
        
        vector2Dlist.add((float) Xcomponent); // adding the calculated x and y velocity vectors to the arraylist.
        vector2Dlist.add((float) Ycomponent);
        
        ComponentXList.add((float) positionX); // adding the calculated x and y position vectors to the arraylist.
        ComponentYList.add((float) positionY);
        
        System.out.println("Velocity Vector: " + vector2Dlist.get(0) + "," + vector2Dlist.get(1));
        System.out.println("Position Vector: " + ComponentXList.get(0) + "," + ComponentYList.get(0) + "\n");
        
        double x = 0;
        while (x <= (time - 0.01)){
        	
            double velociyY = vector2Dlist.get(1) - 9.82 * 0.02; //   velocity vector = x - (9.82 * t)
            double posY = ComponentYList.get(0) + ((vector2Dlist.get(1)+ velociyY)/2) * 0.02; // position vector = x * ((y + velocity_vector.y)/2) * t
            
            vector2Dlist.remove(1);
            vector2Dlist.add((float) velociyY); // adding the velocity vector y to the list.
            
            double x1 = ComponentXList.get(0) + ((Xcomponent + Xcomponent)/2) * 0.02; // x = x + ((x+x)/2) * t
            
            ComponentYList.remove(0); // removing the old position vector
            ComponentYList.add((float) posY); // adding the new position vector after the move
            
            ComponentXList.remove(0);
            ComponentXList.add((float) x1);
            
            System.out.println("Velocity Vector: " + vector2Dlist.get(0) + "," + vector2Dlist.get(1));
            System.out.println("Position Vector: " + ComponentXList.get(0) + "," + ComponentYList.get(0) + "\n");
            
            x += 0.02;
        }
    }
	
	public static void questionC(Vector2D vector2D,double distance,double mass,double force,double angle,double radius){
		ArrayList <Float> vector2Dlist = new ArrayList<Float>();  // arraylists to store the value of x,y before and after the move.
		ArrayList <Float> x1Component = new ArrayList<Float>(); 
		ArrayList <Float> x2Component = new ArrayList<Float>(); 
		ArrayList <Float> y1Component = new ArrayList<Float>(); 
		ArrayList <Float> y2Component = new ArrayList<Float>(); 
		ArrayList <Float> vector2DXComponent = new ArrayList<Float>();
		ArrayList <Float> vector2DYComponent = new ArrayList<Float>();
        double a = force/mass; // f = ma calculating the accelaration.
        
        double v = Math.sqrt((Math.pow(vector2D.getY(),2)) - (2 * a * distance));
        
        double Vb = v * Math.sin(Math.toRadians(angle)); // velocity vector = v * sin(Q)  
        double tyme = ( vector2D.getY() - v)/a; // calculate the time
        double t2 = Vb * Math.sin(Math.toRadians(angle))/a;
        
        double position1X = 0; // POSITION VECTOR BEFORE THE MOVE
        double position1Y = 0;
        
        vector2Dlist.add(vector2D.getX()); // passing the x and y component to the vector2DList arrayList.
        vector2Dlist.add( vector2D.getY());
        
        x1Component.add((float) position1X); // passing the postion vector before the move.
        y1Component.add((float) position1Y);
        
        System.out.println("Moation before the collision of Cue ball" + "\n");
        System.out.println("Position Vector: " + x1Component.get(0) + "," + y1Component.get(0));
        System.out.println("Velocity Vector: " + vector2Dlist.get(0) + "," + vector2Dlist.get(1) + "\n");

        double i = 0;
        while (i <= (tyme - 0.01)){
            double Vay = vector2Dlist.get(1) + (- a * 0.02);
            double pY = y1Component.get(0) + ((vector2Dlist.get(1) + Vay)/2)*0.02;
            
            vector2Dlist.remove(1); // updating the position and velocity vector in arraylist 
            vector2Dlist.add((float) Vay);
            
            y1Component.remove(0);
            y1Component.add((float) pY);
           
            System.out.println("Position Vector: " + x1Component.get(0) + "," + y1Component.get(0));
            System.out.println("Velocity Vector: " + vector2Dlist.get(0) + "," + vector2Dlist.get(1) + "\n");

            i += 0.02;
        }
        vector2DXComponent.add((float)(Vb * Math.cos(Math.toRadians(angle)))); //calculating the velocity vector
        vector2DYComponent.add((float)(Vb * Math.sin(Math.toRadians(angle))));
        
        x2Component.add((float)(x1Component.get(0)+(radius * 2)));
        y2Component.add((float)(y1Component.get(0)+(radius * 2)));
        
        //System.out.println(t2+" "+Vb);
        System.out.println("Motion of the Object ball  after the collision" + "\n");
        System.out.println("Position Vector: " + x2Component.get(0) + "," + y2Component.get(0));
        System.out.println("Velocity Vector: " + vector2DXComponent.get(0) + "," + vector2DYComponent.get(0) + "\n");


        while (i <= (t2 - 0.01)){
            double Vby = vector2DYComponent.get(0) + (- a * 0.02); // calculating the velocity vector after the collision
            double Vbx = vector2DXComponent.get(0) + (- a * 0.02);
            double pY2 = y2Component.get(0) + ((Vby + vector2DYComponent.get(0))/2) * 0.02; // calculating the postion vector after the collision
            double pX2 = x2Component.get(0) + ((Vbx + vector2DXComponent.get(0))/2) * 0.02;
            
            vector2DXComponent.remove(0); // removing the starting velocity of vector
            vector2DYComponent.remove(0);
            
            vector2DXComponent.add((float)Vbx); // adding the final velocity of the vector.
            vector2DYComponent.add((float)Vby);
            
            x2Component.remove(0); // removing the starting position of vector
            y2Component.remove(0);
            
            x2Component.add((float)pX2); // adding the final velocity of vector
            y2Component.add((float)pY2);
           
            
            
            System.out.println("Position Vector: " + x2Component.get(0) + "," + y2Component.get(0));
            System.out.println("Velocity Vector: " + vector2DXComponent.get(0) + "," + vector2DYComponent.get(0) + "\n");
            i += 0.02;
        }
    }
}


public class Vector3D {
	public float x = 0.0f; // instance variables x element
	public float y = 0.0f; // instance variables y element
	public float z = 0.0f; // instance variables z element
	
	public Vector3D(float x, float y, float z) { // parameteraise constructor
		super();
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public Vector3D(){ // default constructor
		
	}
	
	public float getX() { // getter and setters
		return x;
	}
	public void setX(float x) {
		this.x = x;
	}
	public float getY() {
		return y;
	}
	public void setY(float y) {
		this.y = y;
	}
	public float getZ() {
		return z;
	}
	public void setZ(float z) {
		this.z = z;
	}
	
	
	
	
}

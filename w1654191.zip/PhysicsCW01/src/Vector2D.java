
public class Vector2D {
	public float x = 0.0f; // instance variables x element
	public float y = 0.0f;	// instance variables y element
	
	public Vector2D(float x, float y) { // parametariase constructor
		super();
		this.x = x;
		this.y = y;
	}
	
	public Vector2D(){ // default constructor
		
	}

	public float getX() { // getters an setters
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}
	
}

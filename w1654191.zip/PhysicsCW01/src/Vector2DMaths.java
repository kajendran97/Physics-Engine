import java.util.ArrayList;

public class Vector2DMaths {
		
	/* This method is to add two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the addition of both vectors as a 2D vector object
	 */
	public static Vector2D add2DVector(Vector2D vector1 , Vector2D vector2){ 
		Vector2D add2DVector = new Vector2D();
		add2DVector.setX(vector1.getX() + vector2.getX());
		add2DVector.setY(vector1.getY() + vector2.getY());
		return add2DVector;
	}
	/* This method is to add two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the addition of both vectors as a 2D vector object.
	 */
	
	public static Vector2D sub2DVector(Vector2D vector1 , Vector2D vector2){
		Vector2D add2DVector = new Vector2D();
		add2DVector.setX(vector1.getX() - vector2.getX());
		add2DVector.setY(vector1.getY() - vector2.getY());
		return add2DVector;
	}
	
	/* This method is to find the dot product of two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the dot product of both vectors as a float variable.
	 */
	public static float dotProduct(Vector2D vector1 , Vector2D vector2){
		Vector2D add2DVector = new Vector2D();
		add2DVector.setX(vector1.getX() * vector2.getX());
		add2DVector.setY(vector1.getY() * vector2.getY());
		float result = add2DVector.getX() + add2DVector.getY();
		return result;
	}
	
	/* This method is to find the unit vector of two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the unit vector of both vectors as a float variable.
	 */
	public static double unitVector(Vector2D vector1 , Vector2D vector2){
		Vector2D add2DVector = new Vector2D();
		add2DVector.setX(vector1.getX() * vector2.getX());
		add2DVector.setY(vector1.getY() * vector2.getY());
		float result = add2DVector.getX() + add2DVector.getY();
		
		double x = Math.sqrt((vector1.getX() * vector1.getX()) + (vector1.getY() * vector1.getY()));
		double y = Math.sqrt((vector2.getX() * vector2.getX()) + (vector2.getY() * vector2.getY()));

		double ans = Math.cos(result / (x*y));
		return ans;
	}
	
	/* This method is to find the magnitute two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the magnitute of both vectors as a float variable.
	 */
	public static double findMagnitute(Vector2D vector1){
		double result = Math.sqrt((vector1.getX() * vector1.getX()) + (vector1.getY() * vector1.getY()));
		return result;
	}
	
	/* This method is to find the multiple of two vectors and two 2D vector parameters are passed 
	 * to this method and it will return the multiple of both vectors as a 2D vector object.
	 */
	public static Vector2D vectorMultiple(Vector2D vector1,Vector2D vector2){
		Vector2D multiple2DVector = new Vector2D();
		multiple2DVector.setX(vector1.getX() * vector2.getX());
		multiple2DVector.setY(vector1.getY() * vector2.getY());
		return multiple2DVector;
	}
	
	/* This method is to find the rotation of 2D vector and two 2D vector parameter and angle of the vector are passed 
	 * to this method and it will return the vector rotation of both vectors as a 2D vector object.
	 */
	public static Vector2D vectorRotation(Vector2D vector1 , double angle){
		Vector2D rotation2DVector = new Vector2D();
		rotation2DVector.setX((float)((vector1.getX() * Math.cos(Math.toRadians(angle))) - vector1.getY() * Math.sin(Math.toRadians(angle))));
		rotation2DVector.setY((float)((vector1.getX() * Math.cos(Math.toRadians(angle))) + vector1.getY() * Math.sin(Math.toRadians(angle))));
		return rotation2DVector;
	}
	
	/* This method is to find the Velocity of the vector and speed and angle of the vector are passed 
	 * to this method and it will return the velocity vetor of both vectors as a 2D vector object.
	 */
	public static Vector2D findVelocityVector(double speed , double angle){
		Vector2D VelocityVector = new Vector2D();
		VelocityVector.setX((float)(speed * Math.cos(Math.toRadians(angle))));
		VelocityVector.setY((float)(speed * Math.sin(Math.toRadians(angle))));
		return VelocityVector;
	}
	
	/* This method is to find multiplication of vector and two 2D vector parameter and scalar are passed 
	 * to this method and it will return the multiplication of vector as a 2D vector object.
	 */
	public static Vector2D scalarMultiple(Vector2D vector1, double scalar){
		Vector2D ScalarMultipleVector = new Vector2D();
		ScalarMultipleVector.setX((float)(vector1.getX() * scalar));
		ScalarMultipleVector.setY((float)(vector1.getY() * scalar));
		return ScalarMultipleVector;
	}
	
	/* This method is to find the velocity of vector and two speed , time and angle are passed 
	 * to this method and it will return the velocity vector of vector as a 2D vector object.
	 */
//	public static double questionA(double speed,double angle,double time){
//		double v = (Vector2DMaths.findVelocityVector(speed, angle).getY()) - (9.81 * time);
//		Vector2D vector1 = new Vector2D();
//		vector1.setX(Vector2DMaths.findVelocityVector(speed, angle).getX());
//		vector1.setY(Vector2DMaths.findVelocityVector(speed, angle).getY());
//		return v;
//	}
	
	public static void questionB(double time,Vector3D vector3D ,  double mass){
		ArrayList <Float> vector3Dlist = new ArrayList<Float>(); 
		ArrayList <Float> componentXList = new ArrayList<Float>(); // stores the values of X 
		ArrayList <Float> componentYList = new ArrayList<Float>(); // stores the values of Y 
		ArrayList <Float> componentZList = new ArrayList<Float>(); // stores the values of Z 
		
        double posX = 0;
        double posY = 0;
        double posZ = 0;
		
        double tyme = (((time * vector3D.getY())/mass)*2)/9.82;
        double veloX = ((time * vector3D.getX())/mass);
        double veloY = ((time * vector3D.getY())/mass);
        double veloZ = ((time * vector3D.getZ())/mass);
        
        componentXList.add((float) posX);//save in xPosition ArrayList
        componentYList.add((float) posY);
        componentZList.add((float) posZ);
        
        vector3Dlist.add((float) veloX);//save in vector ArrayList
        vector3Dlist.add((float) veloZ);
        vector3Dlist.add((float) veloY);

        System.out.println("Position Vector: " + componentXList.get(0) + "," + componentYList.get(0) + "," + componentZList.get(0));
        System.out.println("Velocity Vector: " + vector3Dlist.get(0) + "," + vector3Dlist.get(2) + "," + vector3Dlist.get(1) + "\n");
        
        double i = 0;
        while (i <= (tyme - 0.01)){
            double vY = vector3Dlist.get(2) + (-(9.82) * 0.02);
            double py = componentYList.get(0) + ((vector3Dlist.get(2) + vY)/2)*0.02; // calculating the new postion vector of Y
            
            vector3Dlist.remove(2);
            vector3Dlist.add((float) vY);
            
            double pX = componentXList.get(0) + ((veloX + veloX)/2) * 0.02; // position vector X = x + ((velocity X + velocity X)/2) * t
            double pZ = componentZList.get(0) + ((veloZ + veloZ)/2) * 0.02;
           
            componentXList.remove(0); // removing the old position of X
            componentXList.add((float) pX); // adding the new position of Y
            
            componentYList.remove(0);
            componentYList.add((float) py);
            
            componentZList.remove(0);
            componentZList.add((float) pZ);
            
            i += 0.02;
            
            System.out.println("Velocity Vector: " + vector3Dlist.get(0) + "," + vector3Dlist.get(2) + "," + vector3Dlist.get(1) + "\n");
            System.out.println("Position Vector: " + componentXList.get(0) + "," + componentYList.get(0) + "," + componentZList.get(0));
            
        }
    }
}
